# Move Claude Code to Ubuntu on Windows — start here

Claude Code runs on Windows through PowerShell, and that is where most of the
breakage comes from: path handling, permissions, line endings, and antivirus
interference. The fix is to run it inside **Ubuntu on WSL2** — a real Linux
environment that ships with Windows, boots in about a second, and shares your
files and network with Windows. Your editor still runs on Windows; only the
terminal and Claude Code move.

**Nothing is deleted.** Everything on the Windows side stays exactly where it is
and keeps working as a fallback.

## What to read

| File | What it is |
|---|---|
| `WSL-Claude-Code-Setup.md` | The full walkthrough. Follow this top to bottom. |
| `WSL-Claude-Code-Setup.docx` | The same walkthrough as a Word document. |
| `reference/troubleshooting.md` | Every problem we hit, and the fix for each. |
| `reference/Troubleshooting.docx` | The same troubleshooting guide as a Word document. |
| `reference/` (the rest) | Copy-paste snippets the walkthrough refers to: editor settings for VS Code and Antigravity, shell additions, and an optional memory cap for Ubuntu. |
| `scripts/` | The four scripts that do the work. Run them in order. |

## The short version

Four commands, in this order. The walkthrough explains each one and what to
expect on screen.

```
1.  Windows PowerShell (as Administrator):   wsl --install -d Ubuntu     → reboot
2.  Ubuntu terminal:                         bash scripts/2-ubuntu-bootstrap.sh
3.  Ubuntu terminal:                         bash scripts/3-migrate-from-windows.sh
4.  Ubuntu terminal:                         bash scripts/4-verify.sh
```

Budget about an hour, most of which is downloads and one reboot.

## Order matters in exactly one place

Run step 3 (the migration) **only after Claude Code is fully closed on the
Windows side** — every window, every terminal tab. Claude Code rewrites its own
settings file while running, so copying it from underneath a live session gives
you a half-written file.

## Two things to have ready before you start

1. **Your Windows username** — the folder name under `C:\Users\`. Not your
   display name, the folder name.
2. **Administrator rights on the laptop**, for step 1 only. Everything after
   that runs as you.
