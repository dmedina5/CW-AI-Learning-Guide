# Running Claude Code on Ubuntu inside Windows

A step-by-step move of your terminal and Claude Code onto Ubuntu on WSL2, with
your settings, prompt history and past conversations carried across, and your
editor pointed at the new terminal.

**Audience:** someone comfortable copying commands into a terminal. No Linux
experience assumed.
**Time:** about an hour, including one reboot.
**Risk:** low. Nothing on the Windows side is modified or deleted. The Windows
copy remains a working fallback for as long as you want it.

---

## Contents

1. What this fixes and what you end up with
2. Before you start
3. Step 1 — Install Ubuntu on Windows
4. Step 2 — First boot into Ubuntu
5. Step 3 — Install the toolchain and Claude Code
6. Step 4 — Make the terminal open Ubuntu by default
7. Step 5 — Point VS Code at Ubuntu
8. Step 6 — Point Antigravity at Ubuntu
9. Step 7 — Carry your Claude Code settings and history across
10. Step 8 — Bring your code across
11. Step 9 — Sign in and verify
12. Your daily routine after this
13. Troubleshooting
14. Appendix A — What each script actually does
15. Appendix B — Backing out

---

## 1. What this fixes and what you end up with

### What WSL is

WSL — "Windows Subsystem for Linux" — is a Linux system that Microsoft ships
inside Windows. It is not a separate computer and not a traditional virtual
machine you have to manage. You open a terminal tab and you are in Ubuntu. It
starts in about a second, shuts down with Windows, and can see your Windows
files and your network, including any company VPN, without extra configuration.

### Why move Claude Code into it

The problems that show up when Claude Code drives a PowerShell session are
mostly not Claude Code problems — they are Windows shell problems that any
Unix-shaped tool hits:

1. **Two different kinds of path.** `C:\Users\you\repo` and `/home/you/repo`
   are not interchangeable, and tools that assume one get confused by the other.
2. **Line endings.** Windows ends every line of a text file with two invisible
   characters; Linux and macOS use one. Check out a repository on Windows with
   the default settings and thousands of files can look modified when nothing
   was touched. On the machine this guide was written from, that was roughly
   3,800 files showing as changed — every one of them a false alarm.
3. **File permissions.** The Unix read/write/execute bits that shell scripts
   depend on have no real equivalent on a Windows drive, so scripts arrive
   without permission to run.
4. **Command name collisions.** Windows can put its own copy of a tool ahead of
   the one you installed, so you end up running a different program than you
   think. Section 13 covers the specific case that bites hardest.
5. **Antivirus.** Real-time scanning inspects every file a build touches, which
   is why the same task can take several times longer on Windows.

Inside Ubuntu, all five stop being your problem.

### What you end up with

1. A **Ubuntu terminal** that opens by default in Windows Terminal.
2. **Claude Code installed natively in Ubuntu**, kept up to date by its own
   updater.
3. **Your settings, prompt history and past conversations** carried over, so
   `claude --resume` finds the work you were in the middle of.
4. **VS Code and Antigravity** opening a Ubuntu shell rather than PowerShell.
5. **Your repositories on the Linux side**, where they are fast and where the
   line-ending problem cannot occur.
6. **The Windows setup untouched**, as a fallback.

### What does *not* change

Your editor is still a normal Windows application. Your browser, Teams, Outlook,
Slack and everything else are untouched. You do not dual-boot, you do not
repartition anything, and you can uninstall the whole thing from Windows
Settings if you decide against it.

---

## 2. Before you start

Work through this list first — each item saves a stall later.

1. **Check your Windows version.** Press `Win`, type `winver`, press Enter.
   You need Windows 11, or Windows 10 version 21H2 or newer. Anything current
   and patched is fine.
2. **Confirm you can run something as Administrator.** Only Step 1 needs it. If
   your laptop is locked down, ask IT to run that one command with you.
3. **Write down your Windows username** — the folder name under `C:\Users\`.
   Open File Explorer, go to `C:\Users\`, and note the exact spelling. It is
   often `firstname.lastname`, and it is not always the same as your display
   name. The migration script can usually detect it, but have it ready.
4. **Note where your code lives on Windows**, e.g. `C:\Users\you\repos`.
5. **Know how you sign in to Claude Code** — the Anthropic account or the
   company login you normally use. You will sign in once more at the end.
6. **Close Claude Code completely.** Every window, every terminal tab. It writes
   to its own settings file while running, and Step 7 copies that file.
7. **Push or commit anything you care about**, or at least know which folders
   have work that is not yet in a branch. Step 8 covers rescuing uncommitted
   work, but it is easier if you know where it is.
8. **Plan for roughly 5 GB of disk** and a reboot.

> **A note on how to read the command blocks.** A block beginning
> `# Windows PowerShell` is typed into PowerShell on the Windows side. A block
> beginning `# Ubuntu` is typed into the Ubuntu terminal. Mixing them up is the
> single most common way to get stuck, and the error messages are unhelpful when
> you do.

---

## 3. Step 1 — Install Ubuntu on Windows

This is the one step that needs Administrator rights, and the one that needs a
reboot.

### 3.1 Open PowerShell as Administrator

Press `Win`, type `powershell`, then right-click **Windows PowerShell** and
choose **Run as administrator**. Accept the prompt. The window title will say
"Administrator".

### 3.2 Install

```powershell
# Windows PowerShell (as Administrator)
wsl --install -d Ubuntu
```

That one command enables the Windows features WSL needs, installs the Linux
kernel, and downloads Ubuntu. Expect a few minutes and a progress bar.

If you would rather not type it, run the included script instead, which does the
same thing plus a couple of safe defaults and prints a checklist:

```powershell
# Windows PowerShell (as Administrator)
powershell -ExecutionPolicy Bypass -File .\scripts\1-windows-install-wsl.ps1
```

### 3.3 Reboot

Reboot when it asks, even if it looks like it finished without needing to. The
virtualisation features it just switched on do not take effect until you do.

### 3.4 After the reboot

Ubuntu usually opens on its own and starts setting itself up. If it does not,
press `Win`, type `Ubuntu`, and open it.

It will ask you to create a username and password:

- **Username:** lowercase, no spaces. It does not have to match your Windows
  username, and short is better — you will type it often. `rachel` is fine.
- **Password:** you will need it whenever you install software. **It will not
  show any characters as you type it — not even dots.** That is normal. Type it,
  press Enter, type it again. Put it in your password manager.

When it finishes you get a prompt like:

```
rachel@LAPTOP-1234:~$
```

That is Ubuntu. You are in.

### 3.5 Confirm you are on WSL version 2

Version 1 is the old implementation and is meaningfully slower. Back in
PowerShell (a normal window is fine now):

```powershell
# Windows PowerShell
wsl --list --verbose
```

You want `VERSION` to read `2`:

```
  NAME      STATE           VERSION
* Ubuntu    Running         2
```

If it says `1`:

```powershell
# Windows PowerShell
wsl --set-version Ubuntu 2
wsl --set-default-version 2
```

Also make Ubuntu the default distribution, so `wsl` on its own lands there:

```powershell
# Windows PowerShell
wsl --set-default Ubuntu
```

---

## 4. Step 2 — First boot into Ubuntu

Two small things before installing anything.

### 4.1 Update the system

In the Ubuntu terminal:

```bash
# Ubuntu
sudo apt update && sudo apt upgrade -y
```

`sudo` means "as administrator" and will ask for the Ubuntu password you just
created. Again, nothing appears as you type. This takes a few minutes the first
time.

### 4.2 Learn the one thing about Windows files

Your Windows C: drive is visible from Ubuntu at `/mnt/c`. Your Windows home
folder is:

```bash
# Ubuntu
ls /mnt/c/Users/<your-windows-username>
```

This is how Step 7 reaches your existing Claude Code settings, and it is why
nothing has to be copied through a USB stick.

**But do not keep your working code there.** Files under `/mnt/c` are reached
through a translation layer, and anything that touches many files at once — a
build, a test run, a `git status` — is several times slower than the same
operation on the Linux side. Keep code in your Ubuntu home folder (`~`), which
is what Step 8 does.

The reverse direction works too: from Windows File Explorer, type
`\\wsl.localhost\Ubuntu\home\<your-ubuntu-username>` into the address bar and
your Linux files appear as a normal folder. Useful for dragging a file out; not
the route for day-to-day work.

---

## 5. Step 3 — Install the toolchain and Claude Code

Run the bootstrap script. First copy this folder into Ubuntu — assuming you
unzipped it to your Windows Downloads:

```bash
# Ubuntu
cp -r /mnt/c/Users/<your-windows-username>/Downloads/wsl-claude-code-setup ~/
cd ~/wsl-claude-code-setup
bash scripts/2-ubuntu-bootstrap.sh
```

It takes a few minutes and prints what it is doing. It is safe to run twice —
it checks before it changes anything.

### What it installs, and why each one

1. **Build essentials, `git`, `curl`, `unzip`, `ripgrep`** — the baseline any
   development tool expects. `ripgrep` is the fast file search Claude Code uses
   to read your codebase.
2. **Node.js (current long-term-support release), into your home folder.** Into
   `~/.local/node` rather than system-wide, so no step ever needs a password and
   nothing can collide with a system package. You only need Node if your own
   projects use it — Claude Code itself does not.
3. **Claude Code**, via Anthropic's own installer:
   ```bash
   curl -fsSL https://claude.ai/install.sh | bash
   ```
   This is the native build. It installs to `~/.local/bin/claude` and updates
   itself, with no Node dependency.
4. **A `PATH` block appended to `~/.bashrc`.** `PATH` is the list of folders your
   shell searches for a command. This puts your Ubuntu tools **ahead of**
   anything inherited from Windows.

**Point 4 is the one that matters most, and it is worth understanding.** WSL
helpfully adds your Windows `PATH` to your Ubuntu one, so Windows programs are
callable from Linux. The side effect is that if Node is installed on Windows,
then typing `npm` in Ubuntu can run **the Windows copy** — which then tries to
build Linux packages with Windows tooling and fails in ways that make no sense
from the error message. On the machine this guide was written from, `npm`
resolved to `/mnt/c/Program Files/nodejs/npm` until the `PATH` order was fixed.
The block the script adds prevents that permanently.

### Close and reopen the terminal

`PATH` is read when a shell starts, so the change does not apply to the tab you
ran the script in. Close it, open a new Ubuntu tab, then check:

```bash
# Ubuntu
which claude          # → /home/<you>/.local/bin/claude
claude --version      # → e.g. 2.1.274 (Claude Code)
which node npm        # → both under /home/<you>/.local/node/bin
```

If `which npm` points at anything beginning `/mnt/c`, the new shell did not pick
up the change — see section 13.

---

## 6. Step 4 — Make the terminal open Ubuntu by default

So that opening a terminal gives you Ubuntu rather than PowerShell.

1. Open **Windows Terminal**.
2. `Ctrl` + `,` for settings.
3. **Startup** → **Default profile** → **Ubuntu**.
4. While you are there, **Startup** → **Default terminal application** →
   **Windows Terminal**. This makes Windows itself open Terminal rather than the
   old console window.
5. **Save**.

PowerShell is still one click away in the dropdown whenever you want it.

---

## 7. Step 5 — Point VS Code at Ubuntu

There are two levels here. Do both — the second is the one that gives you the
clean setup.

### 7.1 Make the integrated terminal open Ubuntu

1. Install the **WSL** extension: `Ctrl` + `Shift` + `X`, search `WSL`, install
   the one published by Microsoft (`ms-vscode-remote.remote-wsl`).
2. `Ctrl` + `Shift` + `P`, type `Preferences: Open User Settings (JSON)`, Enter.
3. Add this inside the outermost `{ }`:

```json
"terminal.integrated.defaultProfile.windows": "Ubuntu (WSL)"
```

The full snippet, with the extra settings worth having, is in
`reference/vscode-settings-snippet.json`.

4. Save, then open a new terminal with `` Ctrl + ` ``. You should get a Ubuntu
   prompt.

### 7.2 Open the *project* in Ubuntu — the better way

Step 7.1 gives you a Ubuntu shell inside a Windows editor. That works, but the
editor is still reading your files through the Windows path, so extensions,
language servers and file watching all pay the slow-path cost.

The better arrangement is to have VS Code attach itself to Ubuntu. From a Ubuntu
terminal, inside a project folder:

```bash
# Ubuntu
cd ~/repos/my-project
code .
```

The first time, this installs a small server component into Ubuntu
automatically. VS Code then opens with **WSL: Ubuntu** shown in the bottom-left
corner. Now the editor, the terminal, the extensions and Claude Code are all on
the Linux side, and everything is consistently fast.

Once you are used to it, this becomes the normal way to open a project.

---

## 8. Step 6 — Point Antigravity at Ubuntu

Antigravity is built on the same foundation as VS Code, so the settings keys are
the same.

### 8.1 Default the terminal to Ubuntu — this works

1. `Ctrl` + `Shift` + `P` → `Preferences: Open User Settings (JSON)` → Enter.
   Use the command palette rather than hunting for the file; the folder name
   differs between builds and the palette always opens the right one.
2. Add, inside the outermost `{ }`:

```json
"terminal.integrated.defaultProfile.windows": "Ubuntu (WSL)"
```

3. Save and open a new terminal panel. Ubuntu prompt.

The ready-made version is in
`reference/antigravity-settings-snippet.json`, including a spelled-out profile
definition to fall back on if `Ubuntu (WSL)` is not offered in the terminal
dropdown.

### 8.2 Opening the project itself in Ubuntu — check before relying on it

**Stated plainly because it is worth not guessing about:** the trick in 7.2 —
`code .` from inside Ubuntu, with the editor attaching to Linux — depends on the
Microsoft WSL extension, and that extension is licensed for Microsoft's own
builds. Whether your Antigravity build can install it depends on which extension
marketplace it is configured against, and that varies by version. Check yours
rather than assuming either way.

If it is available, use it exactly as in 7.2. If it is not, you have two working
options:

1. **Recommended: edit in Antigravity, run Claude Code in Windows Terminal.**
   Open the project over the network path
   `\\wsl.localhost\Ubuntu\home\<you>\repos\my-project`, and keep a Ubuntu tab
   open alongside for `claude`. Claude Code is then fully Linux-native, which is
   the entire point of this exercise. Editing over that path is a little slower
   than local, and completely reliable.
2. **Use VS Code for projects where you want the editor on the Linux side too**,
   and Antigravity for everything else. Nothing about this setup forces one
   editor.

Either way, Step 8.1 alone gets you the outcome you came for: a Ubuntu shell in
your editor, and Claude Code running in Linux.

---

## 9. Step 7 — Carry your Claude Code settings and history across

**Close Claude Code on Windows first.** Every window and every terminal tab. It
rewrites its own settings while running, so copying from underneath a live
session yields a truncated file.

```bash
# Ubuntu
cd ~/wsl-claude-code-setup
bash scripts/3-migrate-from-windows.sh
```

The script finds your Windows profile, shows you exactly what it is about to do,
and **waits for you to type `yes`**. Nothing is copied before that.

To see the plan without doing anything:

```bash
# Ubuntu
bash scripts/3-migrate-from-windows.sh --dry-run
```

If it cannot work out which Windows user you are, or picks the wrong one:

```bash
# Ubuntu
bash scripts/3-migrate-from-windows.sh --windows-user "firstname.lastname"
```

### What comes across

1. **Your settings** — `settings.json` and `settings.local.json`: model choice,
   permission rules, status line, and anything else you have configured.
2. **Your personal instruction file** — the `CLAUDE.md` in your Claude Code
   folder, if you have one.
3. **Your past conversations**, so `claude --resume` finds the work you were in
   the middle of.
4. **Your prompt history**, so pressing `Up` in a new session still walks back
   through what you have typed before.
5. **Your project trust decisions**, so you are not re-asked whether to trust
   every folder.
6. **Your custom commands, agents, skills and output styles**, if you have any.
7. **Your `git` identity** (name and email), plus one corrected setting — see
   below.
8. **Your SSH keys**, with the strict permissions Linux requires. SSH silently
   refuses to use a key that other users could read, which produces a confusing
   "permission denied" if the permissions are not fixed. The script fixes them.

### The part that needs translating, not copying

Claude Code records which folder each conversation belongs to. On Windows those
records say `C:\Users\you\repos\thing`; in Ubuntu the same project is
`/home/you/repos/thing`. Copied verbatim, every past conversation would belong to
a folder that does not exist, and `--resume` would show you nothing.

The script rewrites those references in all three places they appear: the
per-project conversation folders, the project list in the main configuration
file, and the prompt history file. This is exactly the step that is easy to miss
by hand, and it is the difference between arriving with your history and
arriving with an empty slate.

### What is deliberately left behind

1. **Your saved login.** Windows encrypts it in a way that is tied to the
   Windows account, so the copied file would be undecryptable rather than
   merely wrong. You sign in again in Step 9 — one prompt.
2. **Caches, logs, temporary session files and downloaded plugin copies.** All
   regenerate on their own and all can carry stale Windows paths.
3. **Your cloud provider tokens**, if you use any. Short-lived by design; sign
   in again with your normal command.

### One thing it changes rather than copies

Your `git` configuration comes across with `core.autocrlf` set to `false`.
That setting is what asks Git to convert line endings on Windows; on Linux it
causes exactly the false-modification noise described in section 1. Turning it
off here is correct, and it is why the re-clone in Step 8 gives you clean
checkouts.

### A backup is taken first

Anything the script would overwrite is copied to
`~/.claude-migration-backup-<date>` first. Appendix B explains how to put it
back.

---

## 10. Step 8 — Bring your code across

**Re-clone your repositories. Do not copy them from the Windows drive.**

This is counter-intuitive — the files are right there — but copying brings four
problems with it: Windows line endings baked into every file, the wrong
permissions on every script, a `.git` folder holding Windows-shaped paths, and
whatever is cached in `node_modules` or a build folder built for a different
platform.

Re-cloning takes a couple of minutes per repository and produces a checkout that
is correct from the first command:

```bash
# Ubuntu
mkdir -p ~/repos
cd ~/repos
git clone git@github.com:YourOrg/your-repo.git
```

If your organisation uses HTTPS and a browser login rather than SSH keys, use
the GitHub CLI:

```bash
# Ubuntu
sudo apt install -y gh
gh auth login          # choose GitHub.com, then HTTPS, then browser
gh repo clone YourOrg/your-repo
```

One note if you use `gh`: Linux has no equivalent of Windows Credential Manager
here, so the token is stored as a plain file at `~/.config/gh/hosts.yml`. Tighten
it, which costs nothing:

```bash
# Ubuntu
chmod 600 ~/.config/gh/hosts.yml
chmod 700 ~/.config/gh
```

### If you have uncommitted work on the Windows side

Do not lose it. Pick whichever fits.

**Work you are happy to commit** — commit it on Windows, push the branch, pull it
in Ubuntu. Simplest, and nothing is in a single place any more.

**Work you would rather not push** — save it as a patch file and apply it to the
fresh clone:

```bash
# Windows PowerShell, in the repo
git diff > C:\Users\<you>\Desktop\my-changes.patch
```

```bash
# Ubuntu, in the fresh clone
git apply /mnt/c/Users/<you>/Desktop/my-changes.patch
```

**Local branches that exist nowhere else** — carry all of them over at once in a
single file:

```bash
# Windows PowerShell, in the repo
git bundle create C:\Users\<you>\Desktop\my-repo.bundle --all
```

```bash
# Ubuntu, in the fresh clone
git fetch /mnt/c/Users/<you>/Desktop/my-repo.bundle "refs/heads/*:refs/heads/windows/*"
git branch --list "windows/*"
```

Every Windows branch is now available as `windows/<name>`, losslessly, with
nothing to remember to go back for. This is the method that rescued four
commits that existed on no server during the migration this guide is based on.

**Untracked files that are not in Git at all** — configuration files, `.env`
files, local scratch scripts. Copy just those, and only into places where
nothing clean is already sitting:

```bash
# Ubuntu
rsync -av --ignore-existing \
  /mnt/c/Users/<you>/repos/my-repo/.env \
  ~/repos/my-repo/
```

`--ignore-existing` is the safety catch: it never overwrites a file the fresh
clone already produced correctly.

---

## 11. Step 9 — Sign in and verify

### 11.1 Sign in

```bash
# Ubuntu
claude
```

It will ask you to authenticate and open a browser on the Windows side. Sign in
as you normally would. Once. From then on it remembers.

### 11.2 Verify

```bash
# Ubuntu
cd ~/wsl-claude-code-setup
bash scripts/4-verify.sh
```

It checks each of the things that can be quietly wrong and prints a pass or fail
per line, with the fix next to any failure. It changes nothing.

Then Claude Code's own check:

```bash
# Ubuntu
claude doctor
```

### 11.3 The one check worth doing by hand

Open a project and confirm your history followed you:

```bash
# Ubuntu
cd ~/repos/my-project
claude --resume
```

You should see your past conversations for that project listed. If the list is
empty but conversations exist elsewhere, the path translation did not match that
folder — section 13 has the specific fix, and it is recoverable.

---

## 12. Your daily routine after this

Once, at the start of the day:

1. Open Windows Terminal. It lands in Ubuntu.
2. `cd ~/repos/my-project`
3. `claude`

With VS Code:

1. `cd ~/repos/my-project && code .`
2. `` Ctrl + ` `` for the terminal — already Ubuntu.
3. `claude`

Things worth knowing:

- **Keep code in `~`**, not under `/mnt/c`. This is the single biggest
  performance decision in the whole setup.
- **Claude Code updates itself.** No reinstall step.
- **Ubuntu keeps running in the background** after you close the terminal. That
  is intentional and cheap. `wsl --shutdown` in PowerShell stops it if you ever
  want to.
- **Windows programs work from Ubuntu** — `explorer.exe .` opens the current
  folder in File Explorer, which is a genuinely useful bridge.
- **Your Windows setup still works.** Nothing stops you opening PowerShell and
  using the old copy while you build confidence in the new one.

---

## 13. Troubleshooting

The full list, with the reasoning behind each fix, is in
`reference/troubleshooting.md`. The five most likely, in order:

### `claude: command not found`

The shell that ran the installer never reloaded its `PATH`. Open a new Ubuntu
tab. If it persists:

```bash
# Ubuntu
tail -20 ~/.bashrc          # look for the "Claude Code / local toolchain" block
source ~/.bashrc
which claude
```

### `npm` or `node` behaves strangely, or reports a Windows path

You are running the Windows copy. Confirm:

```bash
# Ubuntu
which -a npm
```

If any line begins `/mnt/c/`, the `PATH` block is missing or is being overridden
by something later in `~/.bashrc`. Re-run
`bash scripts/2-ubuntu-bootstrap.sh`, which is safe to run again, then open a
new tab.

### Everything is slow

Check where you are:

```bash
# Ubuntu
pwd
```

If it starts `/mnt/c/`, that is the cause. Move the project to `~` per Step 8.

### Thousands of files show as modified in a fresh clone

Line endings. Confirm and fix:

```bash
# Ubuntu
git config --global core.autocrlf        # should print false or nothing
git config --global core.autocrlf false
git -C ~/repos/my-repo add --renormalize .
git -C ~/repos/my-repo status
```

### `claude --resume` shows no history for a project

The path translation did not match that folder — usually because the project sits
somewhere other than under your Windows home folder. Nothing is lost; the
conversations are there under the old name. `reference/troubleshooting.md`
has the rename command, which is a one-liner.

---

## 14. Appendix A — What each script actually does

Nothing here is a black box. Each script prints what it is doing as it goes, and
can be read in a text editor first.

| Script | Where it runs | What it does | Safe to run twice? |
|---|---|---|---|
| `1-windows-install-wsl.ps1` | Windows PowerShell, as Administrator | Installs WSL2 and Ubuntu, sets version 2 as the default, makes Ubuntu the default distribution, prints the post-reboot checklist | Yes |
| `2-ubuntu-bootstrap.sh` | Ubuntu | Installs base packages, Node's long-term-support release into your home folder, and Claude Code; appends one guarded `PATH` block to `~/.bashrc` | Yes |
| `3-migrate-from-windows.sh` | Ubuntu | Copies your Claude Code settings, conversations, prompt history, trust decisions, `git` identity and SSH keys; translates every Windows path reference to its Linux equivalent; backs up anything it would overwrite | Yes |
| `4-verify.sh` | Ubuntu | Checks the installation and the migration and prints pass or fail per item. Changes nothing | Yes |

The path translation used by script 3 is in
`scripts/lib-rewrite-claude-paths.py`, kept separate so it can be run on its own
if a single project needs re-mapping later.

---

## 15. Appendix B — Backing out

### Undo just the settings migration

Script 3 backs up anything it would overwrite before touching it:

```bash
# Ubuntu
ls -d ~/.claude-migration-backup-*
```

To restore, move the migrated copy aside — renaming rather than deleting, so
there is still a way back if you change your mind again — then put the backup
in its place:

```bash
# Ubuntu
BK=~/.claude-migration-backup-<date>        # use the folder name printed above
mv ~/.claude       ~/.claude.migrated-aside
mv ~/.claude.json  ~/.claude.json.migrated-aside
cp -a "$BK/.claude"      ~/.claude
cp -a "$BK/.claude.json" ~/.claude.json
```

Once you are satisfied, the two `.migrated-aside` items can be deleted at your
leisure.

### Go back to working on Windows

Open PowerShell and carry on. Your Windows installation, settings and
repositories were never modified.

### Remove Ubuntu entirely

```powershell
# Windows PowerShell (as Administrator)
wsl --unregister Ubuntu
```

This deletes the Linux filesystem and everything in it, so move anything you
want to keep out first. Your Windows files are not affected. To remove the
Windows feature as well, uninstall "Windows Subsystem for Linux" from
**Settings → Apps → Installed apps**.
