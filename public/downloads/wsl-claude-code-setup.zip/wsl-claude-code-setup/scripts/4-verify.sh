#!/usr/bin/env bash
# 4-verify.sh
#
# Run inside the Ubuntu (WSL) terminal, last. Checks everything that can be
# quietly wrong and prints the fix next to anything that is. Changes nothing.
#
#   bash scripts/4-verify.sh
#
# Exit code 0 means every check passed.
#
set -uo pipefail

GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RED=$'\033[31m'; CYAN=$'\033[36m'; BOLD=$'\033[1m'; OFF=$'\033[0m'
PASS=0; FAIL=0; WARNED=0

section() { printf '\n%s== %s%s\n' "$CYAN" "$1" "$OFF"; }
ok()   { printf '   %sPASS%s  %s\n' "$GREEN"  "$OFF" "$1"; PASS=$((PASS+1)); }
no()   { printf '   %sFAIL%s  %s\n' "$RED"    "$OFF" "$1"; FAIL=$((FAIL+1));
         [[ -n "${2:-}" ]] && printf '         fix: %s\n' "$2"; }
hm()   { printf '   %sNOTE%s  %s\n' "$YELLOW" "$OFF" "$1"; WARNED=$((WARNED+1));
         [[ -n "${2:-}" ]] && printf '         %s\n' "$2"; }

printf '\n%sClaude Code on Ubuntu - verification%s\n' "$BOLD" "$OFF"

# ------------------------------------------------------------------- the box
section "Environment"

if grep -qi microsoft /proc/version 2>/dev/null; then
  ok "running inside WSL"
  # Which MODE this distribution runs in - not the same question as which
  # version of the WSL package is installed, which is what `wslinfo
  # --wsl-version` answers (it reports something like 2.7.12.0 even for a
  # distribution running in version-1 mode). The kernel identifies itself, and
  # only version 2 provides the virtual-socket device.
  if grep -qi 'WSL2' /proc/version 2>/dev/null || [[ -e /dev/vsock ]]; then
    ok "this distribution runs in WSL version 2 (the fast one)"
  elif grep -qi 'Microsoft' /proc/version 2>/dev/null; then
    no "this distribution runs in WSL version 1, which is much slower" \
       "in PowerShell: wsl --set-version Ubuntu 2   (takes several minutes)"
  else
    hm "could not determine which WSL mode this is" \
       "in PowerShell, run: wsl --list --verbose   and look for VERSION 2"
  fi
else
  hm "this does not look like WSL" "harmless if you meant to run it elsewhere"
fi

case "$HOME" in
  /mnt/*) no "your home folder is on the Windows drive ($HOME)" \
             "this will be slow; a Linux home under /home is what you want" ;;
  *)      ok "home folder is on the Linux side ($HOME)" ;;
esac

# ------------------------------------------------------------------- the tool
section "Claude Code"

CLAUDE_PATH="$(command -v claude 2>/dev/null || true)"
if [[ -z "$CLAUDE_PATH" ]]; then
  no "claude is not on your PATH" \
     "open a NEW terminal tab first; if still missing, rerun scripts/2-ubuntu-bootstrap.sh"
else
  case "$CLAUDE_PATH" in
    /mnt/*) no "claude resolves to the WINDOWS copy ($CLAUDE_PATH)" \
               "the PATH block is missing from ~/.bashrc - rerun scripts/2-ubuntu-bootstrap.sh" ;;
    *)      ok "claude is the Linux build ($CLAUDE_PATH)" ;;
  esac
  ver="$(claude --version 2>/dev/null | head -1)"
  [[ -n "$ver" ]] && ok "version: $ver" \
                  || no "claude will not report its version" "try: claude doctor"
fi

if [[ -f "$HOME/.claude/.credentials.json" ]]; then
  ok "signed in"
else
  hm "no saved login found" "run 'claude' once and sign in; this is expected before you have"
fi

# --------------------------------------------------------------- PATH hygiene
section "PATH order"

# The block this kit adds is one way to get the order right, not the only one.
# What actually matters is whether tools resolve to Linux copies, checked below,
# so a missing block with a correct PATH is a note rather than a failure.
if grep -q "Claude Code / local toolchain" "$HOME/.bashrc" 2>/dev/null; then
  ok "PATH block present in ~/.bashrc"
else
  BAD_RESOLVE=0
  for t in claude node npm; do
    p="$(command -v "$t" 2>/dev/null || true)"
    case "$p" in /mnt/*) BAD_RESOLVE=1 ;; esac
  done
  if [[ $BAD_RESOLVE -eq 1 ]]; then
    no "PATH block missing from ~/.bashrc, and tools resolve to Windows copies" \
       "rerun scripts/2-ubuntu-bootstrap.sh, then open a new terminal tab"
  else
    hm "PATH block not found in ~/.bashrc" \
       "your PATH is already correct, so something else is setting it - fine to leave alone"
  fi
fi

for t in node npm git rg python3; do
  p="$(command -v "$t" 2>/dev/null || true)"
  if [[ -z "$p" ]]; then
    case "$t" in
      node|npm) hm "$t not installed" "only needed if your own projects use it" ;;
      rg)       hm "ripgrep (rg) not installed" "sudo apt install -y ripgrep" ;;
      *)        no "$t not installed" "sudo apt install -y $t" ;;
    esac
  else
    case "$p" in
      /mnt/*) no "$t resolves to the Windows copy ($p)" \
                 "this is the one that causes baffling build failures - fix the PATH block" ;;
      *)      ok "$t -> $p" ;;
    esac
  fi
done

# ---------------------------------------------------------------------- git
section "Git"

gn="$(git config --global user.name  2>/dev/null || true)"
ge="$(git config --global user.email 2>/dev/null || true)"
[[ -n "$gn" ]] && ok "user.name  = $gn"  || no "user.name not set"  "git config --global user.name 'Your Name'"
[[ -n "$ge" ]] && ok "user.email = $ge" || no "user.email not set" "git config --global user.email 'you@company.com'"

crlf="$(git config --global core.autocrlf 2>/dev/null || true)"
if [[ "$crlf" == "false" || -z "$crlf" ]]; then
  ok "core.autocrlf is off (${crlf:-unset}) - checkouts will be clean"
else
  no "core.autocrlf is '$crlf'" \
     "git config --global core.autocrlf false   (then: git add --renormalize .)"
fi

# ------------------------------------------------------------- the migration
section "Migrated settings and history"

if [[ ! -d "$HOME/.claude" ]]; then
  hm "no ~/.claude folder yet" "expected if you have not run the migration or Claude Code yet"
else
  ok "~/.claude exists"

  for f in settings.json settings.local.json; do
    [[ -f "$HOME/.claude/$f" ]] || continue
    if python3 -c "import json,sys; json.load(open(sys.argv[1]))" "$HOME/.claude/$f" 2>/dev/null; then
      ok "$f is valid JSON"
    else
      no "$f is not valid JSON" "restore it from ~/.claude-migration-backup-*"
    fi
  done

  # Any Windows path left behind means resume will come up empty for that project
  leftover=0
  if [[ -d "$HOME/.claude/projects" ]]; then
    n="$(find "$HOME/.claude/projects" -maxdepth 1 -type d -name 'C--*' 2>/dev/null | wc -l | tr -d ' ')"
    if [[ "$n" -gt 0 ]]; then
      no "$n conversation folder(s) still carry Windows names" \
         "rerun: python3 scripts/lib-rewrite-claude-paths.py --windows-home 'C:\\Users\\<you>'"
      leftover=1
    fi
    c="$(find "$HOME/.claude/projects" -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')"
    ok "$((c > 0 ? c - 1 : 0)) project(s) with saved conversations"
  fi

  # Look at the fields that decide which folder a conversation belongs to, not
  # at raw text: a prompt that merely MENTIONS a Windows path is not a problem,
  # and an earlier version of this check flagged exactly that.
  stale="$(python3 - "$HOME/.claude.json" "$HOME/.claude/history.jsonl" <<'PYCHK'
import json, re, sys
WIN = re.compile(r"^[A-Za-z]:[\\/]")
conf, hist = sys.argv[1], sys.argv[2]
bad = []
try:
    with open(conf, encoding="utf-8") as fh:
        for key in (json.load(fh).get("projects") or {}):
            if WIN.match(key):
                bad.append("project list")
                break
except (OSError, ValueError):
    pass
try:
    with open(hist, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                proj = json.loads(line).get("project")
            except ValueError:
                continue
            if isinstance(proj, str) and WIN.match(proj):
                bad.append("prompt history")
                break
except (OSError, ValueError):
    pass
print(", ".join(sorted(set(bad))))
PYCHK
)"
  if [[ -n "$stale" ]]; then
    no "Windows paths still recorded in: $stale" \
       "rerun: python3 scripts/lib-rewrite-claude-paths.py --windows-home 'C:\\Users\\<you>' --linux-home \"\$HOME\""
    leftover=1
  fi
  [[ $leftover -eq 0 ]] && ok "no Windows paths left in the configuration"

  if [[ -d "$HOME/.claude/hooks-from-windows" ]]; then
    hm "hooks staged but not installed" \
       "review ~/.claude/hooks-from-windows/ and move over anything you still want"
  fi
fi

# ----------------------------------------------------------------- ssh keys
section "SSH keys"

if [[ ! -d "$HOME/.ssh" ]]; then
  hm "no ~/.ssh folder" "only matters if you clone over SSH rather than HTTPS"
else
  dperm="$(stat -c '%a' "$HOME/.ssh" 2>/dev/null || echo '?')"
  [[ "$dperm" == "700" ]] && ok "~/.ssh is 700" \
                          || hm "~/.ssh is $dperm, not 700" "chmod 700 ~/.ssh"
  bad=0
  while IFS= read -r k; do
    [[ -n "$k" ]] || continue
    kp="$(stat -c '%a' "$k" 2>/dev/null || echo '?')"
    if [[ "$kp" != "600" && "$kp" != "400" ]]; then
      no "$(basename "$k") is $kp - SSH will refuse to use it" "chmod 600 '$k'"
      bad=1
    fi
  done < <(find "$HOME/.ssh" -maxdepth 1 -type f ! -name '*.pub' ! -name 'known_hosts*' \
             ! -name 'config' 2>/dev/null)
  [[ $bad -eq 0 ]] && ok "private key permissions are correct"
fi

# ------------------------------------------------------------------- summary
section "Summary"

printf '   %s%d passed%s' "$GREEN" "$PASS" "$OFF"
[[ $WARNED -gt 0 ]] && printf ', %s%d to note%s' "$YELLOW" "$WARNED" "$OFF"
[[ $FAIL   -gt 0 ]] && printf ', %s%d failed%s' "$RED" "$FAIL" "$OFF"
printf '\n'

if [[ $FAIL -eq 0 ]]; then
  cat <<'DONE'

   Nothing is broken. The last thing worth doing by hand is opening a project
   you have used before and confirming your history came with you:

     cd ~/repos/<a project you have used before>
     claude --resume

   You should see your past conversations listed.

DONE
  exit 0
else
  cat <<'DONE'

   Work through the failures above, then run this again. Each one prints its
   own fix. If a failure mentions PATH, the first thing to try is opening a
   brand-new terminal tab - PATH is only read when a shell starts.

DONE
  exit 1
fi
