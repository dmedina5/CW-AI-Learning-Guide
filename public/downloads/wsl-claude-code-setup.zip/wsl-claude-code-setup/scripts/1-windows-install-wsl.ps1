#Requires -RunAsAdministrator
<#
    1-windows-install-wsl.ps1
    Run in Windows PowerShell, AS ADMINISTRATOR, before any of the Ubuntu steps.

    Installs WSL2 and Ubuntu, makes both the default, and prints what to do
    after the reboot. Safe to run more than once - it checks before it changes
    anything.
#>

$ErrorActionPreference = 'Stop'

function Say  ($m) { Write-Host "  $m" }
function Head ($m) { Write-Host ""; Write-Host "== $m" -ForegroundColor Cyan }
function Good ($m) { Write-Host "  OK   $m" -ForegroundColor Green }
function Warn ($m) { Write-Host "  WARN $m" -ForegroundColor Yellow }
function Die  ($m) { Write-Host "  STOP $m" -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "Claude Code on Ubuntu - Windows side setup" -ForegroundColor White

# ---------------------------------------------------------------- preflight
Head "Checking this machine"

$os = Get-CimInstance Win32_OperatingSystem
Say "$($os.Caption) build $($os.BuildNumber)"
if ([int]$os.BuildNumber -lt 19044) {
    Die "WSL2 needs Windows 10 build 19044 (version 21H2) or newer. Ask IT to update Windows first."
}
Good "Windows version is new enough"

if (-not ([Security.Principal.WindowsPrincipal] `
          [Security.Principal.WindowsIdentity]::GetCurrent()
         ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Die "This window is not elevated. Close it, then right-click PowerShell and choose 'Run as administrator'."
}
Good "Running as Administrator"

# ------------------------------------------------------------ already there?
Head "Looking for an existing Ubuntu install"

$already = $false
try {
    # wsl writes UTF-16 to stdout; normalise so the match works
    $listing = (& wsl.exe --list --quiet 2>$null) -join "`n" -replace "`0", ""
    if ($listing -match 'Ubuntu') { $already = $true }
} catch { }

if ($already) {
    Good "Ubuntu is already installed on this machine"
} else {
    Head "Installing WSL2 and Ubuntu"
    Say "This downloads a few hundred megabytes. Leave it alone until it finishes."
    & wsl.exe --install -d Ubuntu
    if ($LASTEXITCODE -ne 0) {
        Warn "'wsl --install' exited with code $LASTEXITCODE."
        Warn "On a managed laptop this usually means virtualisation is switched off in firmware,"
        Warn "or the Microsoft Store is blocked by policy. Send that exit code to IT."
        exit $LASTEXITCODE
    }
    Good "Ubuntu installed"
}

# -------------------------------------------------------------- set defaults
Head "Setting defaults"

& wsl.exe --set-default-version 2 2>$null | Out-Null
Good "New distributions will use WSL version 2"

if ($already) {
    & wsl.exe --set-default Ubuntu 2>$null | Out-Null
    Good "Ubuntu is the default distribution"

    $verbose = (& wsl.exe --list --verbose 2>$null) -join "`n" -replace "`0", ""
    if ($verbose -match 'Ubuntu\s+\S+\s+1\b') {
        Warn "Ubuntu is on WSL version 1, which is much slower. Upgrading it now."
        Say  "This can take several minutes and must not be interrupted."
        & wsl.exe --set-version Ubuntu 2
    } else {
        Good "Ubuntu is on WSL version 2"
    }
} else {
    Say "Ubuntu becomes the default automatically once it finishes first-run setup."
}

# ------------------------------------------------------------------- next up
Head "What to do next"

if (-not $already) {
    Write-Host ""
    Write-Host "  1. REBOOT NOW. Do it even if nothing asked you to -" -ForegroundColor Yellow
    Write-Host "     the features just switched on do not take effect until you do." -ForegroundColor Yellow
}

Write-Host @"

  2. Open Ubuntu (press Win, type 'Ubuntu').
     It will ask for a username and password:
       - username: lowercase, no spaces, short. It need not match Windows.
       - password: NOTHING APPEARS AS YOU TYPE, not even dots. That is normal.
     Save the password in your password manager.

  3. Copy this folder into Ubuntu and run the bootstrap - this is "Step 3,
     Install the toolchain and Claude Code" in the walkthrough:

       cp -r /mnt/c/Users/$env:USERNAME/Downloads/wsl-claude-code-setup ~/
       cd ~/wsl-claude-code-setup
       bash scripts/2-ubuntu-bootstrap.sh

     (Adjust the path if you unzipped it somewhere other than Downloads.)

  4. Make the terminal open Ubuntu by default ("Step 4" in the walkthrough):
     Windows Terminal -> Ctrl+, -> Startup -> Default profile -> Ubuntu

  5. CLOSE CLAUDE CODE COMPLETELY on the Windows side - every window and every
     terminal tab - then run the migration ("Step 7" in the walkthrough):

       bash scripts/3-migrate-from-windows.sh

  Your Windows username, which item 3 above needs, is: $env:USERNAME
  The full walkthrough is WSL-Claude-Code-Setup.md (or the .docx) beside this
  scripts folder.

"@

Good "Windows side done"
Write-Host ""
