#!/usr/bin/env bash
# 3-migrate-from-windows.sh
#
# Run inside the Ubuntu (WSL) terminal, AFTER 2-ubuntu-bootstrap.sh and AFTER
# closing Claude Code completely on the Windows side.
#
# Brings your Claude Code settings, past conversations, prompt history, trust
# decisions, git identity and SSH keys over from the Windows profile, and
# translates every Windows path reference to its Linux equivalent.
#
#   bash scripts/3-migrate-from-windows.sh
#   bash scripts/3-migrate-from-windows.sh --dry-run
#   bash scripts/3-migrate-from-windows.sh --windows-user firstname.lastname
#   bash scripts/3-migrate-from-windows.sh --yes            (no confirmation)
#
set -uo pipefail

BOLD=$'\033[1m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RED=$'\033[31m'; CYAN=$'\033[36m'; OFF=$'\033[0m'
section() { printf '\n%s== %s%s\n' "$CYAN" "$1" "$OFF"; }
say()  { printf '   %s\n' "$1"; }
good() { printf '   %sOK%s   %s\n' "$GREEN" "$OFF" "$1"; }
warn() { printf '   %sWARN%s %s\n' "$YELLOW" "$OFF" "$1"; }
die()  { printf '\n   %sSTOP%s %s\n\n' "$RED" "$OFF" "$1"; exit 1; }

WIN_USER=""
DRY_RUN=0
ASSUME_YES=0
while [[ $# -gt 0 ]]; do
  case "$1" in
    --windows-user) WIN_USER="${2:-}"; shift 2 ;;
    --dry-run)      DRY_RUN=1; shift ;;
    --yes|-y)       ASSUME_YES=1; shift ;;
    -h|--help)      sed -n '2,20p' "$0"; exit 0 ;;
    *)              die "unknown option: $1" ;;
  esac
done

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REWRITER="$SCRIPT_DIR/lib-rewrite-claude-paths.py"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$HOME/.claude-migration-backup-$STAMP"
BACKUP_TAKEN=0
NOTES=()

printf '\n%sClaude Code - bring your Windows setup across%s\n' "$BOLD" "$OFF"

command -v python3 >/dev/null 2>&1 || die "python3 is missing. Run: sudo apt install -y python3"
[[ -f "$REWRITER" ]] || die "cannot find $REWRITER - run this from inside the unzipped folder"

# ------------------------------------------------- find the Windows profile
section "Finding your Windows profile"

# Normally /mnt/c/Users. Override if Windows is mounted somewhere else, or to
# rehearse this against a copy of a profile rather than the live one.
WIN_USERS_ROOT="${CLAUDE_MIGRATE_WINDOWS_ROOT:-/mnt/c/Users}"
[[ -d "$WIN_USERS_ROOT" ]] || die "$WIN_USERS_ROOT is not visible. Is this really WSL, and is the C: drive mounted?"

if [[ -z "$WIN_USER" ]]; then
  CANDIDATES=()
  for d in "$WIN_USERS_ROOT"/*/; do
    name="$(basename "$d")"
    case "$name" in
      Default|"Default User"|Public|"All Users"|desktop.ini) continue ;;
    esac
    if [[ -d "$d/.claude" || -f "$d/.claude.json" ]]; then
      CANDIDATES+=("$name")
    fi
  done

  if [[ ${#CANDIDATES[@]} -eq 1 ]]; then
    WIN_USER="${CANDIDATES[0]}"
    good "Found one Windows profile with Claude Code in it: $WIN_USER"
  elif [[ ${#CANDIDATES[@]} -gt 1 ]]; then
    warn "More than one Windows profile has Claude Code installed:"
    for c in "${CANDIDATES[@]}"; do say "  - $c"; done
    die "Pick one:  bash scripts/3-migrate-from-windows.sh --windows-user '<name>'"
  else
    warn "No Windows profile under $WIN_USERS_ROOT has a Claude Code folder."
    say  "Either Claude Code was never run on Windows - in which case there is"
    say  "nothing to migrate and you can skip straight to step 9 - or it lives"
    say  "under a different profile. Profiles present:"
    for d in "$WIN_USERS_ROOT"/*/; do say "  - $(basename "$d")"; done
    die "Name it explicitly with --windows-user '<name>' if you know it."
  fi
fi

WIN_HOME="$WIN_USERS_ROOT/$WIN_USER"
[[ -d "$WIN_HOME" ]] || die "no such Windows profile: $WIN_HOME"
WIN_CLAUDE_DIR="$WIN_HOME/.claude"
WIN_CLAUDE_JSON="$WIN_HOME/.claude.json"
WIN_PATH_SPELLING="C:\\Users\\$WIN_USER"

say "Windows profile : $WIN_HOME"
say "Recorded in Claude Code as: $WIN_PATH_SPELLING"
say "Moving to       : $HOME"

# ------------------------------------------------------ is it still running?
section "Checking Claude Code is closed on the Windows side"

if command -v tasklist.exe >/dev/null 2>&1; then
  if tasklist.exe 2>/dev/null | tr -d '\r' | grep -qi '^claude'; then
    warn "A Claude Code process is still running on Windows."
    warn "It rewrites its own settings file as it goes, so copying now can give"
    warn "you a half-written file. Close every Claude Code window and tab, then"
    die  "run this again."
  fi
  good "No Claude Code process found running on Windows"
else
  warn "Cannot check from here (tasklist.exe not reachable)."
  warn "Make sure Claude Code is closed on Windows before you continue."
  NOTES+=("could not verify Claude Code was closed on Windows")
fi

# ------------------------------------------------------------- what we'll do
section "The plan"

cat <<PLAN
   Copy across, from $WIN_CLAUDE_DIR:
     - settings.json and settings.local.json   your preferences
     - CLAUDE.md                               your personal instructions
     - projects/                               your past conversations
     - history.jsonl                           your prompt history
     - commands/ agents/ skills/ output-styles/  anything custom you added
     - todos/                                  in-flight task lists

   Merge $WIN_CLAUDE_JSON into ~/.claude.json
     - your per-project trust decisions, so no folder re-asks
     - this machine's own identity and install details stay as they are

   Translate every '$WIN_PATH_SPELLING...' reference into '$HOME...'
     - in the conversation folder names, the project list, the prompt
       history, the settings files, and inside the conversations themselves

   Copy your git identity, and set core.autocrlf to false
   Copy your SSH keys, with the strict permissions Linux insists on

   Deliberately NOT copied:
     - your saved login (Windows ties it to the Windows account; sign in again)
     - caches, logs, temporary session files, downloaded plugin copies
     - hooks/  (staged for review instead - they hold absolute paths)

   Anything that would be overwritten is backed up first, to:
     $BACKUP
PLAN

if [[ $DRY_RUN -eq 1 ]]; then
  warn "DRY RUN - nothing will be written"
elif [[ $ASSUME_YES -eq 0 ]]; then
  printf '\n   %sType yes to go ahead:%s ' "$BOLD" "$OFF"
  read -r reply
  [[ "$reply" == "yes" ]] || die "Nothing was changed."
fi

run() { if [[ $DRY_RUN -eq 1 ]]; then say "would: $*"; else "$@"; fi; }

# -------------------------------------------------------------------- backup
section "Backing up what is here now"

if [[ -d "$HOME/.claude" || -f "$HOME/.claude.json" ]]; then
  run mkdir -p "$BACKUP"
  [[ -d "$HOME/.claude"      ]] && run cp -a "$HOME/.claude"      "$BACKUP/.claude"
  [[ -f "$HOME/.claude.json" ]] && run cp -a "$HOME/.claude.json" "$BACKUP/.claude.json"
  BACKUP_TAKEN=1
  good "Backed up to $BACKUP"
  say  "Appendix B of the walkthrough explains how to put it back."
else
  good "Nothing here yet - no backup needed"
fi

# ---------------------------------------------------------------- copy files
section "Copying your Claude Code files"

if [[ ! -d "$WIN_CLAUDE_DIR" ]]; then
  warn "No $WIN_CLAUDE_DIR on the Windows side - skipping this part"
else
  run mkdir -p "$HOME/.claude"

  # Single files. Overwritten deliberately: the Windows copy is the one with
  # your history in it, and the backup above is the way back.
  for f in settings.json settings.local.json CLAUDE.md history.jsonl; do
    if [[ -f "$WIN_CLAUDE_DIR/$f" ]]; then
      run cp -a "$WIN_CLAUDE_DIR/$f" "$HOME/.claude/$f"
      good "$f"
    fi
  done

  # Folders. --ignore-existing never overwrites something already correct
  # here, which matters for projects/ if you have already used Claude Code
  # in Ubuntu before running this.
  HAVE_RSYNC=0
  command -v rsync >/dev/null 2>&1 && HAVE_RSYNC=1
  for d in projects todos output-styles commands agents skills; do
    src="$WIN_CLAUDE_DIR/$d"
    [[ -d "$src" ]] || continue
    if [[ $HAVE_RSYNC -eq 1 ]]; then
      run rsync -a --ignore-existing "$src/" "$HOME/.claude/$d/"
    else
      run mkdir -p "$HOME/.claude/$d"
      run cp -an "$src/." "$HOME/.claude/$d/"
    fi
    n="$(find "$src" -type f 2>/dev/null | wc -l | tr -d ' ')"
    good "$d/  ($n files)"
  done

  # Hooks are staged, not installed: they are shell or PowerShell scripts full
  # of absolute paths, and a Windows-shaped hook that fires on every prompt is
  # a bad surprise. Review them, then move what you want.
  if [[ -d "$WIN_CLAUDE_DIR/hooks" ]]; then
    run mkdir -p "$HOME/.claude/hooks-from-windows"
    if [[ $HAVE_RSYNC -eq 1 ]]; then
      run rsync -a "$WIN_CLAUDE_DIR/hooks/" "$HOME/.claude/hooks-from-windows/"
    else
      run cp -a "$WIN_CLAUDE_DIR/hooks/." "$HOME/.claude/hooks-from-windows/"
    fi
    warn "hooks/ staged at ~/.claude/hooks-from-windows/ rather than installed"
    NOTES+=("review ~/.claude/hooks-from-windows/ and move over what you still want")
  fi
fi

# --------------------------------------------------------- merge + translate
section "Merging the configuration and translating paths"

MERGE_ARG=()
if [[ -f "$WIN_CLAUDE_JSON" ]]; then
  MERGE_ARG=(--merge-from "$WIN_CLAUDE_JSON")
else
  warn "No $WIN_CLAUDE_JSON - trust decisions will not carry over"
  NOTES+=("no Windows .claude.json found; folders may re-ask to be trusted")
fi

REWRITE_ARGS=()
for f in settings.json settings.local.json; do
  [[ -f "$HOME/.claude/$f" ]] && REWRITE_ARGS+=(--rewrite-json "$HOME/.claude/$f")
done

PY_DRY=()
[[ $DRY_RUN -eq 1 ]] && PY_DRY=(--dry-run)

python3 "$REWRITER" \
  --windows-home "$WIN_PATH_SPELLING" \
  --linux-home "$HOME" \
  --claude-dir "$HOME/.claude" \
  --claude-json "$HOME/.claude.json" \
  "${MERGE_ARG[@]}" "${REWRITE_ARGS[@]}" "${PY_DRY[@]}" \
  || { warn "The translation step reported a problem - read the output above"
       NOTES+=("path translation did not finish cleanly; ~/.claude.json may need a second pass"); }

# ------------------------------------------------------------ git identity
section "Git identity and line endings"

if [[ -f "$WIN_HOME/.gitconfig" ]]; then
  GN="$(git config -f "$WIN_HOME/.gitconfig" user.name  2>/dev/null || true)"
  GE="$(git config -f "$WIN_HOME/.gitconfig" user.email 2>/dev/null || true)"
  if [[ -n "$GN" ]]; then run git config --global user.name  "$GN"; good "user.name  = $GN"; fi
  if [[ -n "$GE" ]]; then run git config --global user.email "$GE"; good "user.email = $GE"; fi
  [[ -z "$GN$GE" ]] && warn "Windows .gitconfig has no name or email set - set them yourself"
else
  warn "No .gitconfig on the Windows side. Set your identity by hand:"
  say  "  git config --global user.name  'Your Name'"
  say  "  git config --global user.email 'you@company.com'"
  NOTES+=("set your git user.name and user.email")
fi

run git config --global core.autocrlf false
good "core.autocrlf = false  (this is what stops every file looking modified)"

# ------------------------------------------------------------------ SSH keys
section "SSH keys"

if [[ -d "$WIN_HOME/.ssh" ]]; then
  run mkdir -p "$HOME/.ssh"
  copied=0
  for f in "$WIN_HOME/.ssh"/*; do
    [[ -f "$f" ]] || continue
    b="$(basename "$f")"
    if [[ -e "$HOME/.ssh/$b" ]]; then
      say "kept the copy already here: $b"
      continue
    fi
    run cp "$f" "$HOME/.ssh/$b"
    copied=$((copied+1))
  done
  # SSH refuses to use a key other users could read, and says only
  # "permission denied", which sends people hunting in the wrong place.
  run chmod 700 "$HOME/.ssh"
  if [[ $DRY_RUN -eq 0 ]]; then
    find "$HOME/.ssh" -maxdepth 1 -type f ! -name '*.pub' ! -name 'known_hosts*' \
      -exec chmod 600 {} \; 2>/dev/null
    find "$HOME/.ssh" -maxdepth 1 -type f \( -name '*.pub' -o -name 'known_hosts*' \) \
      -exec chmod 644 {} \; 2>/dev/null
  fi
  good "$copied key file(s) copied, permissions tightened"
  say  "Test it with:  ssh -T git@github.com"
  say  "(GitHub always answers with a non-zero exit code even on success -"
  say  " what matters is that it greets you by name.)"
else
  say "No .ssh folder on the Windows side - nothing to copy"
fi

# ------------------------------------------------------------------- wrap up
section "Done"

if [[ $DRY_RUN -eq 1 ]]; then
  warn "That was a dry run. Nothing was written."
  say  "Run it again without --dry-run to do it for real."
  exit 0
fi

if [[ ${#NOTES[@]} -gt 0 ]]; then
  printf '\n   %sWorth a look:%s\n' "$YELLOW" "$OFF"
  for n in "${NOTES[@]}"; do printf '     - %s\n' "$n"; done
fi

if [[ $BACKUP_TAKEN -eq 1 ]]; then
  BACKUP_LINE="   Whatever was here before this ran is backed up at:
     $BACKUP
"
else
  BACKUP_LINE="   There was nothing here before this ran, so no backup was needed.
"
fi

cat <<NEXT

   ${BOLD}Next:${OFF}

   1. Sign in. Your Windows login could not come across, by design:

        claude

   2. Check everything landed:

        bash scripts/4-verify.sh

   3. Open a project and confirm your history followed you:

        cd ~/repos/<a project you have used before>
        claude --resume

   Your Windows setup is untouched and still works.
$BACKUP_LINE
NEXT
