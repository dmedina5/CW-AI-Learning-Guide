Scripts, in the order you run them
==================================

  1-windows-install-wsl.ps1     Windows PowerShell, AS ADMINISTRATOR
  2-ubuntu-bootstrap.sh         Ubuntu terminal
  3-migrate-from-windows.sh     Ubuntu terminal, after closing Claude Code on Windows
  4-verify.sh                   Ubuntu terminal, last

  lib-rewrite-claude-paths.py   A helper that script 3 calls. Also usable on
                                its own if one project's history needs
                                re-pointing later. Run it with --help.

Every one of them is safe to run twice: each checks before it changes
anything. Scripts 3 and 4 both take --dry-run / --help.

How to run them
---------------

  Windows, elevated PowerShell:
      powershell -ExecutionPolicy Bypass -File .\1-windows-install-wsl.ps1

  Ubuntu:
      bash scripts/2-ubuntu-bootstrap.sh
      bash scripts/3-migrate-from-windows.sh
      bash scripts/4-verify.sh

None of them is a black box - they print what they are doing as they go, and
they are plain text you can open and read first.
