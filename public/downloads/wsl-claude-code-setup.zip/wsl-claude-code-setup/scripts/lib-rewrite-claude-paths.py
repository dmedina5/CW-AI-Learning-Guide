#!/usr/bin/env python3
"""
lib-rewrite-claude-paths.py

Translate Windows paths to their Linux equivalents inside a migrated Claude
Code configuration. Called by 3-migrate-from-windows.sh; also usable on its
own if one project needs re-mapping later.

Claude Code records which folder each conversation belongs to. Those records
say C:\\Users\\you\\repos\\thing on Windows and /home/you/repos/thing in
Ubuntu. Copied verbatim, every conversation points at a folder that does not
exist and `claude --resume` shows nothing.

Three places hold those references:

  1. ~/.claude/projects/<mangled-path>/     - one folder per project, named
                                              after the path with every
                                              non-alphanumeric character
                                              replaced by a dash
  2. ~/.claude.json  -> "projects" keys     - absolute paths, plus trust and
                                              per-project settings
  3. ~/.claude/history.jsonl                - "project" field on each entry

Usage:
  lib-rewrite-claude-paths.py --windows-home 'C:\\Users\\you' \\
                              --linux-home   '/home/you' \\
                              [--claude-dir ~/.claude] \\
                              [--claude-json ~/.claude.json] \\
                              [--merge-from /path/to/source/.claude.json] \\
                              [--skip-transcript-contents] [--dry-run]

Every write is atomic: a temporary file is written and then renamed, so an
interrupted run cannot leave a half-written configuration behind.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import sys
import tempfile
from pathlib import Path

# Top-level keys in .claude.json that describe THIS machine's installation and
# must keep their local values rather than the Windows ones.
KEEP_LOCAL = {
    "machineID",
    "userID",
    "installMethod",
    "autoUpdates",
    "autoUpdatesProtectedForNative",
    "firstStartTime",
    "firstStartVersion",
    "numStartups",
    "migrationVersion",
    "cachedGrowthBookFeatures",
    "changelogLastFetched",
    "cachedChangelog",
}


def log(msg: str) -> None:
    print(f"   {msg}", flush=True)


def mangle(path: str) -> str:
    """Reproduce Claude Code's project-folder naming.

    Every character that is not a letter or a digit becomes a dash, so
    /home/you/.claude becomes -home-you--claude (the slash and the dot each
    contribute one dash).
    """
    return re.sub(r"[^A-Za-z0-9]", "-", path)


def build_matcher(windows_home: str) -> re.Pattern[str]:
    """A regex matching the Windows home path however it is spelled.

    Separators may be backslash or forward slash, in any number, because the
    same path appears escaped, unescaped and URL-ish in different files. The
    lookahead stops C:\\Users\\dan from matching inside C:\\Users\\daniel.
    """
    parts = [p for p in re.split(r"[\\/]+", windows_home.strip()) if p]
    if not parts:
        raise ValueError(f"unusable --windows-home: {windows_home!r}")
    body = r"[\\/]+".join(re.escape(p) for p in parts)
    return re.compile(
        body + r"(?=$|[\\/]|[^A-Za-z0-9_.\-])" + r"((?:[\\/][^\s\"']*)?)",
        re.IGNORECASE,
    )


# Text saved by a Windows tool in the legacy Western-European encoding and then
# read back as UTF-8 turns an em dash into "a-hat euro quote-mark" and similar.
# It is cosmetic but it lands in settings files and reads as corruption.
MOJIBAKE_HINT = re.compile(r"\u00c3|\u00e2\u20ac")


def repair_mojibake(value: str) -> str:
    if not MOJIBAKE_HINT.search(value):
        return value
    try:
        fixed = value.encode("cp1252", errors="strict").decode("utf-8", errors="strict")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return value
    return fixed


def make_rewriter(matcher: re.Pattern[str], linux_home: str):
    """Return a function that rewrites one string, and a hit counter."""
    stats = {"hits": 0}

    def rewrite(value: str) -> str:
        def repl(m: re.Match[str]) -> str:
            stats["hits"] += 1
            tail = m.group(1) or ""
            # separators normalised, and a run of them collapsed - Windows
            # paths reach us with one, two or four backslashes depending on
            # how many times the value has been through a JSON encoder
            tail = re.sub(r"/{2,}", "/", tail.replace("\\", "/"))
            return linux_home + tail

        return repair_mojibake(matcher.sub(repl, value))

    return rewrite, stats


def walk(obj, rewrite):
    """Rewrite every string inside a JSON structure, keys included."""
    if isinstance(obj, str):
        return rewrite(obj)
    if isinstance(obj, list):
        return [walk(v, rewrite) for v in obj]
    if isinstance(obj, dict):
        return {walk(k, rewrite): walk(v, rewrite) for k, v in obj.items()}
    return obj


def write_atomic(path: Path, text: str, dry_run: bool) -> None:
    if dry_run:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=path.name + ".tmp.")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(text)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


# --------------------------------------------------------------------------
# 1. project folders
# --------------------------------------------------------------------------
def rename_project_dirs(claude_dir: Path, windows_home: str, linux_home: str,
                        dry_run: bool) -> int:
    projects = claude_dir / "projects"
    if not projects.is_dir():
        log("no projects folder - nothing to rename")
        return 0

    # The folder name is the path with every non-alphanumeric character
    # replaced by a dash, so match on the alphanumeric runs and let any run of
    # non-alphanumerics join them. That way it matches whether a character
    # such as an underscore was preserved or dashed.
    runs = [r for r in re.split(r"[^A-Za-z0-9]+", windows_home.strip()) if r]
    if not runs:
        log("unusable Windows home - skipping folder renames")
        return 0
    win_prefix_rx = re.compile(
        "^" + r"[^A-Za-z0-9]+".join(re.escape(r) for r in runs)
        + r"(?=$|[^A-Za-z0-9])",
        re.IGNORECASE,
    )
    linux_prefix = mangle(linux_home)

    renamed = 0
    for entry in sorted(projects.iterdir()):
        if not entry.is_dir():
            continue
        m = win_prefix_rx.match(entry.name)
        if not m:
            continue
        new_name = linux_prefix + entry.name[m.end():]
        if new_name == entry.name:
            continue
        target = projects / new_name
        if target.exists():
            # Both a Windows-era and a Linux-era folder exist for the same
            # project. Merge rather than clobber: move the files across and
            # keep anything already there.
            log(f"merge  {entry.name}  ->  {new_name}")
            if not dry_run:
                for f in entry.iterdir():
                    dest = target / f.name
                    if dest.exists():
                        dest = target / (f.stem + ".from-windows" + f.suffix)
                    shutil.move(str(f), str(dest))
                entry.rmdir()
        else:
            log(f"rename {entry.name}  ->  {new_name}")
            if not dry_run:
                entry.rename(target)
        renamed += 1

    if renamed == 0:
        log("no Windows-named project folders found")
    return renamed


# --------------------------------------------------------------------------
# 2. .claude.json
# --------------------------------------------------------------------------
def fix_claude_json(claude_json: Path, merge_from: Path | None, rewrite,
                    dry_run: bool) -> None:
    local: dict = {}
    if claude_json.is_file():
        try:
            local = json.loads(claude_json.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            log(f"WARNING existing {claude_json.name} is unreadable ({exc}); starting fresh")
            local = {}

    if merge_from is not None:
        if not merge_from.is_file():
            log(f"WARNING no source file at {merge_from} - skipping merge")
            return
        try:
            source = json.loads(merge_from.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            log(f"WARNING source {merge_from} is unreadable ({exc}) - skipping merge")
            return

        source = walk(source, rewrite)

        merged = dict(local)
        brought = []
        for key, value in source.items():
            if key in KEEP_LOCAL:
                continue
            if key == "projects" and isinstance(value, dict):
                projects = dict(local.get("projects") or {})
                for ppath, pconf in value.items():
                    if ppath in projects and isinstance(projects[ppath], dict) \
                       and isinstance(pconf, dict):
                        # local values win; Windows fills in the gaps
                        combined = dict(pconf)
                        combined.update(projects[ppath])
                        projects[ppath] = combined
                    else:
                        projects[ppath] = pconf
                merged["projects"] = projects
                brought.append(f"projects ({len(value)} from Windows)")
                continue
            merged[key] = value
            brought.append(key)

        log(f"merged {len(brought)} settings into {claude_json.name}")
        log(f"kept this machine's own: {', '.join(sorted(KEEP_LOCAL & set(local)))or 'none yet'}")
        out = merged
    else:
        out = walk(local, rewrite)

    write_atomic(claude_json, json.dumps(out, indent=2, ensure_ascii=False) + "\n", dry_run)


# --------------------------------------------------------------------------
# 3. history.jsonl and transcript contents
# --------------------------------------------------------------------------
def fix_jsonl(path: Path, rewrite, dry_run: bool) -> int:
    """Rewrite paths inside a JSON-lines file. Unparseable lines pass through
    untouched rather than being dropped."""
    if not path.is_file():
        return 0
    changed = 0
    out_lines: list[str] = []
    with path.open("r", encoding="utf-8", errors="replace") as fh:
        for line in fh:
            stripped = line.strip()
            if not stripped:
                out_lines.append(line)
                continue
            try:
                obj = json.loads(stripped)
            except json.JSONDecodeError:
                out_lines.append(line)
                continue
            new = walk(obj, rewrite)
            if new != obj:
                changed += 1
                out_lines.append(json.dumps(new, ensure_ascii=False) + "\n")
            else:
                out_lines.append(line if line.endswith("\n") else line + "\n")
    if changed and not dry_run:
        write_atomic(path, "".join(out_lines), dry_run)
    return changed


def fix_transcripts(claude_dir: Path, rewrite, dry_run: bool) -> tuple[int, int]:
    projects = claude_dir / "projects"
    if not projects.is_dir():
        return (0, 0)
    files = sorted(projects.rglob("*.jsonl"))
    touched = 0
    for i, f in enumerate(files, 1):
        if i % 100 == 0:
            log(f"... {i}/{len(files)} conversation files")
        try:
            if fix_jsonl(f, rewrite, dry_run):
                touched += 1
        except OSError as exc:
            log(f"WARNING could not rewrite {f.name}: {exc}")
    return (touched, len(files))


# --------------------------------------------------------------------------
def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--windows-home", required=True,
                    help=r"e.g. 'C:\Users\firstname.lastname'")
    ap.add_argument("--linux-home", default=str(Path.home()))
    ap.add_argument("--claude-dir", default=str(Path.home() / ".claude"))
    ap.add_argument("--claude-json", default=str(Path.home() / ".claude.json"))
    ap.add_argument("--merge-from", default=None,
                    help="source .claude.json to merge in (Windows copy)")
    ap.add_argument("--rewrite-json", action="append", default=[], metavar="PATH",
                    help="extra JSON file to translate in place (settings.json and "
                         "settings.local.json hold paths too). Repeatable.")
    ap.add_argument("--skip-transcript-contents", action="store_true",
                    help="rename folders and fix the config, but do not rewrite "
                         "paths recorded inside each conversation file")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    claude_dir = Path(args.claude_dir).expanduser()
    claude_json = Path(args.claude_json).expanduser()
    linux_home = str(Path(args.linux_home).expanduser()).rstrip("/")

    try:
        matcher = build_matcher(args.windows_home)
    except ValueError as exc:
        print(f"ERROR {exc}", file=sys.stderr)
        return 2

    rewrite, stats = make_rewriter(matcher, linux_home)

    print(f"\n   Translating {args.windows_home}  ->  {linux_home}")
    if args.dry_run:
        print("   DRY RUN - nothing will be written\n")

    print("\n   [1/4] project folders")
    rename_project_dirs(claude_dir, args.windows_home, linux_home, args.dry_run)

    print("\n   [2/4] main configuration file")
    merge_from = Path(args.merge_from).expanduser() if args.merge_from else None
    fix_claude_json(claude_json, merge_from, rewrite, args.dry_run)

    print("\n   [3/4] prompt history")
    n = fix_jsonl(claude_dir / "history.jsonl", rewrite, args.dry_run)
    log(f"{n} history entries re-pointed")

    if args.rewrite_json:
        print("\n   [3b/4] settings files")
        for raw in args.rewrite_json:
            f = Path(raw).expanduser()
            if not f.is_file():
                continue
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError) as exc:
                log(f"WARNING {f.name} is unreadable ({exc}) - left as is")
                continue
            fixed = walk(data, rewrite)
            if fixed != data:
                write_atomic(f, json.dumps(fixed, indent=2, ensure_ascii=False) + "\n",
                             args.dry_run)
                log(f"{f.name} translated")
            else:
                log(f"{f.name} needed no change")

    print("\n   [4/4] paths recorded inside conversations")
    if args.skip_transcript_contents:
        log("skipped on request")
    else:
        touched, total = fix_transcripts(claude_dir, rewrite, args.dry_run)
        log(f"{touched} of {total} conversation files updated")

    print(f"\n   {stats['hits']} Windows path references translated in total\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
