#!/usr/bin/env bash
# 2-ubuntu-bootstrap.sh
#
# Run inside the Ubuntu (WSL) terminal. Installs the base toolchain, Node's
# long-term-support release, and Claude Code, then fixes the PATH order so
# Ubuntu tools win over Windows ones.
#
# Safe to run more than once: every step checks before it changes anything.
#
#   bash scripts/2-ubuntu-bootstrap.sh              normal run
#   bash scripts/2-ubuntu-bootstrap.sh --no-node    skip Node
#
set -uo pipefail

NODE_WANTED=1
[[ "${1:-}" == "--no-node" ]] && NODE_WANTED=0

BOLD=$'\033[1m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RED=$'\033[31m'; CYAN=$'\033[36m'; OFF=$'\033[0m'
section() { printf '\n%s== %s%s\n' "$CYAN" "$1" "$OFF"; }
say()  { printf '   %s\n' "$1"; }
good() { printf '   %sOK%s   %s\n' "$GREEN" "$OFF" "$1"; }
warn() { printf '   %sWARN%s %s\n' "$YELLOW" "$OFF" "$1"; }
bad()  { printf '   %sFAIL%s %s\n' "$RED" "$OFF" "$1"; }

NODE_DIR="$HOME/.local/node"
BIN_DIR="$HOME/.local/bin"
MARKER="# >>> Claude Code / local toolchain (added by 2-ubuntu-bootstrap.sh) >>>"
ENDMARK="# <<< Claude Code / local toolchain <<<"
APT_OK=1
PROBLEMS=()

printf '\n%sClaude Code on Ubuntu - toolchain bootstrap%s\n' "$BOLD" "$OFF"

# ------------------------------------------------------------------ sanity
section "Checking where we are"

if ! grep -qi microsoft /proc/version 2>/dev/null; then
  warn "This does not look like WSL. The script still works on plain Linux,"
  warn "but the Windows-PATH fix below will have nothing to fix."
else
  good "Running under WSL"
fi

ARCH_RAW="$(uname -m)"
case "$ARCH_RAW" in
  x86_64)  NODE_ARCH=x64 ;;
  aarch64) NODE_ARCH=arm64 ;;
  *)       NODE_ARCH="" ; warn "Unrecognised CPU architecture '$ARCH_RAW' - will skip Node" ;;
esac
say "User: $(whoami)   Home: $HOME   Arch: $ARCH_RAW"

# -------------------------------------------------------------- apt packages
section "Installing base packages"

PKGS=(build-essential curl git unzip xz-utils ca-certificates ripgrep jq rsync less)
MISSING=()
for p in "${PKGS[@]}"; do
  dpkg -s "$p" >/dev/null 2>&1 || MISSING+=("$p")
done

if [[ ${#MISSING[@]} -eq 0 ]]; then
  good "All base packages already present"
else
  say "Need: ${MISSING[*]}"
  say "This asks for your Ubuntu password. Nothing appears as you type it."
  if sudo apt-get update -qq && sudo apt-get install -y -qq "${MISSING[@]}"; then
    good "Base packages installed"
  else
    APT_OK=0
    bad "Package install failed"
    warn "If it asked for a password you do not have, ask IT for sudo rights"
    warn "on this WSL distribution. Node and Claude Code below need no password"
    warn "and will still install, so let the script finish."
    PROBLEMS+=("base packages not installed - rerun this script once sudo works")
  fi
fi

# ---------------------------------------------------------------------- Node
section "Installing Node.js (long-term-support release)"

if [[ $NODE_WANTED -eq 0 ]]; then
  say "Skipped (--no-node). Claude Code does not need it."
elif [[ -z "$NODE_ARCH" ]]; then
  warn "Skipped - unsupported architecture"
elif [[ -x "$NODE_DIR/bin/node" ]]; then
  good "Already installed: $("$NODE_DIR/bin/node" --version) in $NODE_DIR"
  say  "To move to a newer release later, delete that folder and rerun this script."
else
  say "Asking nodejs.org which release is current LTS..."
  NODE_VER="$(curl -fsSL --max-time 30 https://nodejs.org/dist/index.json 2>/dev/null \
              | jq -r 'map(select(.lts != false)) | .[0].version' 2>/dev/null)"

  if [[ -z "${NODE_VER:-}" || "$NODE_VER" == "null" ]]; then
    warn "Could not resolve the current LTS version (no network, or jq missing)."
    warn "Skipping Node. Rerun this script later, or install it yourself."
    PROBLEMS+=("Node not installed - rerun this script when online")
  else
    TARBALL="node-${NODE_VER}-linux-${NODE_ARCH}.tar.xz"
    say "Installing $NODE_VER into $NODE_DIR (no password needed)"
    TMP="$(mktemp -d)"
    if curl -fsSL --max-time 300 -o "$TMP/$TARBALL" \
         "https://nodejs.org/dist/${NODE_VER}/${TARBALL}" \
       && mkdir -p "$NODE_DIR" \
       && tar -xJf "$TMP/$TARBALL" -C "$NODE_DIR" --strip-components=1; then
      good "Node $("$NODE_DIR/bin/node" --version) installed"
    else
      bad "Node install failed"
      PROBLEMS+=("Node not installed - see the error above")
    fi
    rm -rf "$TMP"
  fi
fi

# --------------------------------------------------------------- Claude Code
section "Installing Claude Code"

if [[ -x "$BIN_DIR/claude" ]]; then
  good "Already installed: $("$BIN_DIR/claude" --version 2>/dev/null || echo 'version unavailable')"
  say  "It updates itself, so there is nothing to do here."
else
  say "Downloading Anthropic's installer (installs to $BIN_DIR/claude, no password needed)"
  if curl -fsSL --max-time 300 https://claude.ai/install.sh | bash; then
    if [[ -x "$BIN_DIR/claude" ]]; then
      good "Claude Code installed: $("$BIN_DIR/claude" --version 2>/dev/null || echo 'installed')"
    else
      bad "The installer finished but no program appeared at $BIN_DIR/claude"
      PROBLEMS+=("Claude Code missing - see https://docs.claude.com/en/docs/claude-code")
    fi
  else
    bad "Installer failed"
    warn "Usually a network or proxy problem. Check you can reach https://claude.ai"
    warn "from this terminal:  curl -I https://claude.ai"
    PROBLEMS+=("Claude Code not installed - see the error above")
  fi
fi

# ----------------------------------------------------------------- PATH order
section "Fixing PATH order in ~/.bashrc"

say "WSL adds the Windows PATH to your Linux one, so a Windows copy of a tool"
say "can shadow the Linux one. This block puts your Ubuntu tools first."

touch "$HOME/.bashrc"
if grep -qF "$MARKER" "$HOME/.bashrc"; then
  good "PATH block already present - leaving it alone"
else
  cp -a "$HOME/.bashrc" "$HOME/.bashrc.bak-before-claude-setup-$(date +%Y%m%d-%H%M%S)"
  cat >> "$HOME/.bashrc" <<'BASHRC'

# >>> Claude Code / local toolchain (added by 2-ubuntu-bootstrap.sh) >>>
# Ubuntu tools must come BEFORE the Windows paths that WSL appends, or a
# Windows copy of node/npm/python can shadow the Linux one and fail in
# confusing ways. Order here is deliberate: do not move these lines lower.
[ -d "$HOME/.local/node/bin" ] && PATH="$HOME/.local/node/bin:$PATH"
[ -d "$HOME/.local/bin" ]      && PATH="$HOME/.local/bin:$PATH"
export PATH
# <<< Claude Code / local toolchain <<<
BASHRC
  good "PATH block appended (previous ~/.bashrc backed up alongside it)"
fi

# -------------------------------------------------------------------- summary
section "Summary"

export PATH="$HOME/.local/node/bin:$HOME/.local/bin:$PATH"
printf '   %-14s %s\n' "claude"  "$(command -v claude || echo 'not found')"
printf '   %-14s %s\n' "node"    "$(command -v node   || echo 'not installed')"
printf '   %-14s %s\n' "npm"     "$(command -v npm    || echo 'not installed')"
printf '   %-14s %s\n' "git"     "$(command -v git    || echo 'not installed')"
printf '   %-14s %s\n' "rg"      "$(command -v rg     || echo 'not installed')"

if [[ ${#PROBLEMS[@]} -gt 0 ]]; then
  printf '\n   %sUnfinished business:%s\n' "$YELLOW" "$OFF"
  for p in "${PROBLEMS[@]}"; do printf '     - %s\n' "$p"; done
fi

cat <<NEXT

   ${BOLD}Next:${OFF}

   1. CLOSE THIS TERMINAL TAB and open a new Ubuntu one. PATH is read when a
      shell starts, so the change above does not apply to this tab.

   2. In the new tab, check:

        which claude       # /home/$(whoami)/.local/bin/claude
        which npm          # must NOT start with /mnt/c
        claude --version

   3. Close Claude Code completely on the Windows side, then bring your
      settings and history across:

        bash scripts/3-migrate-from-windows.sh

NEXT
