# Additions for ~/.bashrc
#
# 2-ubuntu-bootstrap.sh appends the first block automatically. The rest is
# optional - paste in whichever parts you want, then open a new terminal tab.

# ===========================================================================
# REQUIRED: PATH order
# ===========================================================================
# WSL appends your Windows PATH to your Linux one so that Windows programs are
# callable from Ubuntu. The side effect is that a Windows copy of a tool can
# come FIRST and shadow the Linux one. With Node installed on Windows, typing
# `npm` in Ubuntu can run the Windows executable, which then tries to build
# Linux packages with Windows tooling and fails in ways the error message does
# not explain.
#
# These two lines put your own tools ahead of everything inherited. Keep them
# where they are: anything later in this file that rewrites PATH will undo them.

[ -d "$HOME/.local/node/bin" ] && PATH="$HOME/.local/node/bin:$PATH"
[ -d "$HOME/.local/bin" ]      && PATH="$HOME/.local/bin:$PATH"
export PATH

# ===========================================================================
# OPTIONAL: shortcuts
# ===========================================================================

# Jump to your code
alias repos='cd ~/repos'

# Open the current folder in Windows File Explorer - a genuinely useful bridge
alias here='explorer.exe .'

# Open the current folder in VS Code, attached to Linux
alias c='code .'

# Claude Code, resuming the last conversation in this folder
alias cc='claude --continue'

# Which copy of a command am I actually running? The answer to most
# "why is this behaving oddly" moments in WSL.
alias whichall='which -a'

# ===========================================================================
# OPTIONAL: warn when you are working on the slow side
# ===========================================================================
# Files under /mnt/c are reached through a translation layer. Anything that
# touches many files - a build, a test run, git status - is several times
# slower there. This prints a one-line reminder if a shell starts in one.

case "$PWD" in
  /mnt/*)
    printf '\033[33mNote:\033[0m this folder is on the Windows drive, so file '
    printf 'operations here are slow.\n      Your Linux home is %s\n' "$HOME"
    ;;
esac

# ===========================================================================
# OPTIONAL: keep SSH keys unlocked for the session
# ===========================================================================
# Only useful if your key has a passphrase. Starts one agent per login rather
# than one per terminal tab.

if [ -z "${SSH_AUTH_SOCK:-}" ] && command -v ssh-agent >/dev/null 2>&1; then
  if [ -f "$HOME/.ssh-agent-env" ]; then
    . "$HOME/.ssh-agent-env" >/dev/null
  fi
  if ! kill -0 "${SSH_AGENT_PID:-0}" 2>/dev/null; then
    ssh-agent -s > "$HOME/.ssh-agent-env"
    chmod 600 "$HOME/.ssh-agent-env"
    . "$HOME/.ssh-agent-env" >/dev/null
  fi
fi
