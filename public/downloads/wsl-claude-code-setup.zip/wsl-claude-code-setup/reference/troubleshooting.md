# Troubleshooting

Every problem that came up building and testing this, with the reason behind
each fix rather than just the command. Find your symptom in the list.

---

## Contents

- [Installing WSL](#installing-wsl)
- [Claude Code will not start](#claude-code-will-not-start)
- [The wrong copy of a tool is running](#the-wrong-copy-of-a-tool-is-running)
- [Everything is slow](#everything-is-slow)
- [Git says every file changed](#git-says-every-file-changed)
- [My history did not come across](#my-history-did-not-come-across)
- [SSH and GitHub](#ssh-and-github)
- [The editor](#the-editor)
- [Networking and VPN](#networking-and-vpn)
- [Memory and disk](#memory-and-disk)
- [Starting over](#starting-over)

---

## Installing WSL

### `wsl --install` fails, or exits with an error code

Almost always one of three things on a work laptop:

1. **Virtualisation is switched off in firmware.** WSL2 needs it. It is a BIOS
   or UEFI setting, usually called Intel VT-x, AMD-V, or just
   "Virtualization Technology". Changing it means a reboot into firmware
   settings — this is an IT job on a managed machine.
2. **Policy blocks the Microsoft Store**, which is where the Ubuntu image comes
   from. Send IT the exact exit code.
3. **Windows is too old.** `winver` must show Windows 11, or Windows 10 version
   21H2 or newer.

Send the exit code, not a description — it tells IT which of the three it is.

### It installed, but Ubuntu never opens

Start it explicitly:

```powershell
# Windows PowerShell
wsl -d Ubuntu
```

If that complains the distribution is not installed, install just the image —
the Windows features are already in place from the first command:

```powershell
# Windows PowerShell (as Administrator)
wsl --install -d Ubuntu
```

### It says Ubuntu is on WSL version 1

Version 1 is the old implementation and is meaningfully slower.

```powershell
# Windows PowerShell
wsl --set-version Ubuntu 2
wsl --set-default-version 2
```

The conversion takes several minutes and must not be interrupted.

### I forgot the Ubuntu password I just set

Reset it from Windows, without needing the old one:

```powershell
# Windows PowerShell
wsl -d Ubuntu -u root passwd <your-ubuntu-username>
```

Then set a new one. This works because the root account inside WSL does not
require a password from the Windows side.

---

## Claude Code will not start

### `claude: command not found`

`PATH` — the list of folders the shell searches for a command — is only read
when a shell starts. The tab that ran the installer has the old one.

1. Close the terminal tab and open a new Ubuntu one. This fixes it most of the
   time.
2. If it does not, check the block is actually there:

```bash
# Ubuntu
tail -20 ~/.bashrc
```

You are looking for a block headed `Claude Code / local toolchain`. If it is
missing, re-run the bootstrap — it is safe to run twice:

```bash
# Ubuntu
bash scripts/2-ubuntu-bootstrap.sh
```

3. If the block is there but the command still is not found, check the program
   itself exists:

```bash
# Ubuntu
ls -l ~/.local/bin/claude
```

Nothing there means the install did not complete. Run it again and read the
output rather than scrolling past it:

```bash
# Ubuntu
curl -fsSL https://claude.ai/install.sh | bash
```

### The installer itself fails to download

Check you can reach the site from inside Ubuntu, which is not the same question
as whether your browser can:

```bash
# Ubuntu
curl -I https://claude.ai
```

A hang or a certificate error usually means a corporate proxy that Windows
knows about and Ubuntu does not. Ask IT for the proxy address, then:

```bash
# Ubuntu
export HTTPS_PROXY=http://proxy.company.com:8080
export HTTP_PROXY=http://proxy.company.com:8080
curl -fsSL https://claude.ai/install.sh | bash
```

If that works, add those two lines to `~/.bashrc` so they persist.

### `claude` starts but cannot sign in

The sign-in opens a browser on the Windows side. If nothing opens, it will
print a URL — copy it into your browser by hand. If the browser signs in but
the terminal keeps waiting, the loopback callback is being blocked; try:

```bash
# Ubuntu
claude auth --help
```

and use the token-based route it describes.

---

## The wrong copy of a tool is running

This is the single most confusing class of WSL problem, and it is worth
understanding once rather than working around repeatedly.

WSL appends your Windows `PATH` to your Ubuntu one so Windows programs are
callable from Linux — a genuinely useful bridge. The side effect is that if a
tool is installed on Windows *and* in Ubuntu, the Windows one can come first.
You then run a Windows executable that tries to do Linux work, and the errors
describe a symptom nowhere near the cause.

### How to see it

```bash
# Ubuntu
which -a npm
which -a node
which -a python3
```

`-a` lists every match in order. Anything beginning `/mnt/c/` is a Windows
program. If a `/mnt/c/` line appears **above** a `/home/` line, that is your
problem.

On the machine this guide was written from, `npm` resolved to
`/mnt/c/Program Files/nodejs/npm` until the `PATH` order was corrected — and
the failures it caused looked like broken packages, not a wrong `npm`.

### The fix

Re-run the bootstrap, which appends the ordering block, then open a new tab:

```bash
# Ubuntu
bash scripts/2-ubuntu-bootstrap.sh
```

If the block is present and it still resolves wrongly, something later in
`~/.bashrc` is rewriting `PATH` after it. Open the file and move the block to
the very end.

### The heavy-handed option, and why not to reach for it first

You can stop WSL importing the Windows `PATH` at all. Create `/etc/wsl.conf`:

```bash
# Ubuntu
sudo tee /etc/wsl.conf >/dev/null <<'EOF'
[interop]
appendWindowsPath = false
EOF
```

Then `wsl --shutdown` in PowerShell.

This works, and it also breaks `code .`, `explorer.exe`, `clip.exe` and every
other Windows program you might want to call from Ubuntu. Fix the order
instead; only reach for this if the order genuinely cannot be made to stick.

---

## Everything is slow

### Check which side of the fence you are on

```bash
# Ubuntu
pwd
```

If it starts `/mnt/c/`, that is the answer. Files there are reached through a
translation layer, and anything touching many files at once — a build, a test
run, `git status` on a large repository — is several times slower.

Move the project to the Linux side. Re-clone rather than copy, for the reasons
in Step 8 of the walkthrough:

```bash
# Ubuntu
mkdir -p ~/repos && cd ~/repos
git clone git@github.com:YourOrg/your-repo.git
```

### It is slow even in the Linux home folder

1. **Antivirus.** Real-time scanning inspects the WSL disk image. An exclusion
   for `%LOCALAPPDATA%\Packages\CanonicalGroupLimited*` and for `vmmem` /
   `vmmemWSL` typically makes a large difference. On a managed laptop this
   needs IT — ask for it specifically rather than in general terms.
2. **Memory pressure.** See [Memory and disk](#memory-and-disk).
3. **A first run of anything is slow**, because nothing is cached yet. Judge the
   second run.

---

## Git says every file changed

### Thousands of modified files in a fresh clone

Line endings. Windows ends every line with two invisible characters; Linux uses
one. With Git's Windows default, checking out on one platform and reading on
the other makes every line look edited.

```bash
# Ubuntu
git config --global core.autocrlf        # want: false, or nothing at all
git config --global core.autocrlf false
git -C ~/repos/my-repo add --renormalize .
git -C ~/repos/my-repo status
```

`add --renormalize` re-reads every file with the corrected setting. After it,
`status` should be clean — and the changes it reported were never real. Roughly
3,800 files showed this way during the migration this guide is based on, every
one a false alarm.

### It came back after I copied files from Windows

Copying carries the Windows line endings inside the file contents, so the
setting alone cannot save you. Re-clone. It takes two minutes and the result is
correct from the first command.

### Every script says "permission denied"

Files copied from a Windows drive arrive without the Unix bit that marks them
executable.

```bash
# Ubuntu
chmod +x path/to/script.sh
```

For a whole tree of shell scripts:

```bash
# Ubuntu
find ~/repos/my-repo -name '*.sh' -type f -exec chmod +x {} +
```

Another reason to re-clone: Git records the executable bit, so a fresh clone
has it right.

---

## My history did not come across

### `claude --resume` shows nothing in a project

Claude Code stores each project's conversations in a folder named after the
project's path, with every non-alphanumeric character replaced by a dash. A
Windows project at `C:\Users\you\repos\api` is stored under
`C--Users-you-repos-api`; in Ubuntu the same project wants
`-home-you-repos-api`. If the rename did not happen, the conversations are
still there, under a name Claude Code no longer looks for.

Look:

```bash
# Ubuntu
ls ~/.claude/projects/ | head -40
```

Any folder starting `C--` was missed. Re-run the translation — it is safe to
run again, and it only touches names that still need changing:

```bash
# Ubuntu
python3 scripts/lib-rewrite-claude-paths.py \
  --windows-home 'C:\Users\your.windows.username' \
  --linux-home "$HOME"
```

Add `--dry-run` first if you want to see what it would do.

### The project was not under my Windows home folder

If your code lived somewhere like `D:\work\api`, the translation had no reason
to touch it, because it only rewrites paths under the Windows home folder you
named. Run it again with that root and the matching destination:

```bash
# Ubuntu
python3 scripts/lib-rewrite-claude-paths.py \
  --windows-home 'D:\work' \
  --linux-home "$HOME/repos"
```

### Every folder asks me to trust it again

The per-project trust decisions live in `~/.claude.json`. Either the Windows
copy was not merged, or it was merged before the paths were translated. Re-run
the migration — it backs up first and is safe to run again:

```bash
# Ubuntu
bash scripts/3-migrate-from-windows.sh
```

### My prompt history is missing

Check the file arrived:

```bash
# Ubuntu
wc -l ~/.claude/history.jsonl
```

A missing or empty file means it was not copied — re-run the migration. If it
has lines but pressing `Up` shows nothing for a project, its entries still
carry Windows paths, which the verification script reports as a failure. The
translation above fixes it.

---

## SSH and GitHub

### `Permission denied (publickey)`

Nine times in ten this is file permissions, not the key. SSH refuses to use a
private key that other users could read, and says only "permission denied" —
which sends people hunting in entirely the wrong place.

```bash
# Ubuntu
chmod 700 ~/.ssh
chmod 600 ~/.ssh/id_ed25519      # or id_rsa
chmod 644 ~/.ssh/id_ed25519.pub
ssh -T git@github.com
```

### `ssh -T git@github.com` prints a greeting but "exits 1"

That is correct behaviour and not an error. GitHub always closes the connection
with a non-zero exit code because there is no shell to give you. What matters
is the line that greets you by name. Any script that treats that exit code as
failure has a bug — one such false alarm cost an afternoon during the migration
this guide is based on.

### The GitHub CLI keeps asking me to log in

Linux has no equivalent of Windows Credential Manager here, so `gh` stores its
token as a plain file. If the file is unreadable or was never written, it asks
again every time.

```bash
# Ubuntu
gh auth status
gh auth login          # GitHub.com, then HTTPS, then browser
chmod 600 ~/.config/gh/hosts.yml
chmod 700 ~/.config/gh
```

### My clone URL has a token embedded in it

Check before you push anywhere:

```bash
# Ubuntu
git -C ~/repos/my-repo remote -v
```

A URL of the form `https://<long-token>@github.com/...` has a credential in it,
which ends up in your shell history, in backups and in any log that records the
command. Replace it:

```bash
# Ubuntu
git -C ~/repos/my-repo remote set-url origin git@github.com:YourOrg/my-repo.git
```

Then revoke the exposed token at <https://github.com/settings/tokens> —
stripping it locally does not revoke it.

---

## The editor

### `code .` says command not found

The `code` command comes from the Windows VS Code installation, reached through
the interop bridge. Either VS Code is not installed on Windows, or the
`appendWindowsPath` option discussed above has been turned off. Install VS Code
on Windows, then open a new Ubuntu tab.

### VS Code opens, but in Windows rather than Ubuntu

Look at the bottom-left corner. It should read **WSL: Ubuntu**. If it does not,
install the WSL extension (`ms-vscode-remote.remote-wsl`), then use
`Ctrl+Shift+P` → `WSL: Reopen Folder in WSL`.

### The integrated terminal still opens PowerShell

The setting is per-platform, and the Windows one is what applies here even
though you want a Linux shell. The key must be exactly:

```json
"terminal.integrated.defaultProfile.windows": "Ubuntu (WSL)"
```

Setting `...defaultProfile.linux` instead does nothing, because the editor is
running on Windows. If `Ubuntu (WSL)` is not offered in the dropdown, define
the profile by hand — the block is in
`reference/vscode-settings-snippet.json`.

### Antigravity will not install the WSL extension

Expected, possibly. That extension is licensed for Microsoft's own builds, and
whether an Antigravity build can install it depends on which extension
marketplace it is configured against. Step 8.1 of the walkthrough still works
regardless, because it uses the `wsl.exe` that ships with Windows and needs no
extension. See `reference/antigravity-settings-snippet.json` for the
spelled-out profile.

### My extensions disappeared when I opened a folder in WSL

They did not; they are installed on the Windows side and the editor is now on
the Linux side. Open the extensions panel and you will see a section offering
to install them in WSL. Install the ones you need there. This is by design —
extensions that read your files have to live where the files are.

---

## Networking and VPN

### The company VPN does not work from Ubuntu

It usually does, without anything being installed inside Ubuntu, because WSL2
routes through the Windows network stack. Test the thing you actually need
rather than testing the VPN in general:

```bash
# Ubuntu
curl -I https://internal-service.company.com
```

Working means you are done — do not install a VPN client inside Ubuntu.

### DNS does not resolve

WSL generates `/etc/resolv.conf` from the Windows configuration, and some VPN
clients leave it stale.

```bash
# Ubuntu
cat /etc/resolv.conf
```

First try restarting WSL, which regenerates it — in PowerShell:

```powershell
wsl --shutdown
```

If it keeps happening, pin your own. Stop WSL from regenerating the file, then
write it:

```bash
# Ubuntu
sudo tee /etc/wsl.conf >/dev/null <<'EOF'
[network]
generateResolvConf = false
EOF
```

`wsl --shutdown` in PowerShell, then back in Ubuntu:

```bash
# Ubuntu
sudo tee /etc/resolv.conf >/dev/null <<'EOF'
nameserver 8.8.8.8
nameserver 1.1.1.1
EOF
```

Use your company's DNS servers rather than those two if you need internal
names to resolve.

---

## Memory and disk

### Windows gets sluggish while something runs in Ubuntu

WSL2 will take up to about half your RAM if something inside it asks for it,
and does not hand it back promptly. Cap it — the file and the settings are in
`reference/wslconfig-example.txt`.

### The WSL disk image keeps growing and never shrinks

It grows on demand and does not shrink on its own, so space freed inside Ubuntu
is not returned to Windows. Reclaim it:

```powershell
# Windows PowerShell (as Administrator)
wsl --shutdown
diskpart
```

Then inside `diskpart`, substituting your own username:

```
select vdisk file="C:\Users\<you>\AppData\Local\Packages\CanonicalGroupLimited.Ubuntu_79rhkp1fndgsc\LocalState\ext4.vhdx"
attach vdisk readonly
compact vdisk
detach vdisk
exit
```

The exact folder name varies with the Ubuntu version — check what is actually
under `...\Local\Packages\` first.

### How much space am I using?

```bash
# Ubuntu
df -h /                        # the Linux filesystem
du -sh ~/repos/* 2>/dev/null   # per repository
du -sh ~/.claude               # Claude Code's own data
```

Conversation transcripts accumulate. They are worth keeping — that is your
history — but they are the usual answer to where the space went.

---

## Starting over

### Redo just the settings migration

The migration backs up anything it would overwrite:

```bash
# Ubuntu
ls -d ~/.claude-migration-backup-*
bash scripts/3-migrate-from-windows.sh
```

It is safe to run twice, and takes a fresh backup each time.

### Undo the settings migration

Move the migrated copy aside rather than deleting it, so there is still a way
back if you change your mind again:

```bash
# Ubuntu
BK=~/.claude-migration-backup-<date>          # use a folder name from above
mv ~/.claude       ~/.claude.migrated-aside
mv ~/.claude.json  ~/.claude.json.migrated-aside
cp -a "$BK/.claude"      ~/.claude
cp -a "$BK/.claude.json" ~/.claude.json
```

### Start Ubuntu over from scratch

This deletes the Linux filesystem and everything in it. Move anything you want
to keep out first — your Windows files are not affected.

```powershell
# Windows PowerShell (as Administrator)
wsl --unregister Ubuntu
wsl --install -d Ubuntu
```

### Give up and go back to Windows

Open PowerShell and carry on. Nothing on the Windows side was modified at any
point in this process.
